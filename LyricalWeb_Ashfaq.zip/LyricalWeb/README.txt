PREREQUISITES:

- Visual Studio 2019
- .NET Core 3.1
- npm



- Please load in Visual Studio 2019

- Perform a full build (if Visual Studio doesn't install the npm packages) 
  go to the ClientApp folder and run "npm install"

- Run from within Visual Studio in IIS Express.