﻿using System;

namespace LyricalWeb.Services.MusicBrainz.Models
{
    public class ArtistResponse
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}