﻿namespace LyricalWeb.Services.MusicBrainz.Models
{
    public class TrackResponse
    {
        public string Title { get; set; }
    }
}