﻿using System;

namespace LyricalWeb.Services.LyricsOvh.Models
{
    public class LyricsResponse
    {
        public string Lyrics { get; set; }
    }
}