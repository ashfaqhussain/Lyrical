using System;

namespace LyricalWeb.ViewModels
{
    public class ArtistWordsViewModel
    {
        public int AverageWordCount { get; set; }
    }
}
